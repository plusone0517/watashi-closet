import {defineConfig} from 'vite';
export default defineConfig({root:'release',server:{host:'0.0.0.0',allowedHosts:['terminal.local']}});
