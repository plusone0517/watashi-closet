import assert from 'node:assert/strict';
import {nextDate,validDate,validateEvent,overlap,onDay,collisionIds} from '../lib/planner.ts';
const event=(id:string,start:string,end:string,allDay=false)=>validateEvent({id,title:'確認用',category:'work',start,end,allDay,location:'',note:'',updatedAt:''});
assert.equal(nextDate('2028-02-28'),'2028-02-29');assert.equal(nextDate('2026-12-31'),'2027-01-01');assert.equal(validDate('2026-02-30'),false);
const a=event('a','2026-10-01T10:00','2026-10-01T11:00');const b=event('b','2026-10-01T11:00','2026-10-01T12:00');const c=event('c','2026-10-01T10:30','2026-10-01T11:30');
assert.equal(overlap(a,b),false);assert.equal(overlap(a,c),true);assert.equal(overlap(a,{...a,id:'a'}),false);assert.deepEqual([...collisionIds([a,b,c])].sort(),['a','b','c']);
const full=event('d','2026-10-01T00:00','2026-10-03T00:00',true);assert.equal(onDay(full,'2026-10-02'),true);assert.equal(onDay(full,'2026-10-03'),false);assert.equal(overlap(a,full),false);
assert.throws(()=>event('x','2026-10-01T10:00','2026-10-01T09:00'));assert.throws(()=>event('x','2026-02-30T10:00','2026-03-01T10:00'));
console.log('Date, all-day boundary, time-overlap and invalid input checks passed.');
