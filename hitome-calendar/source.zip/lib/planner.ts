export const CATEGORIES = [
  { id: 'work', name: '本業', color: '#315ace', soft: '#edf2ff', caption: '仕事の予定' },
  { id: 'side', name: '副業', color: '#8d4bb7', soft: '#f6edfb', caption: 'もうひとつの仕事' },
  { id: 'family', name: '家族', color: '#cb602d', soft: '#fff1e8', caption: '大切な人との時間' },
  { id: 'self', name: '自分', color: '#0a827b', soft: '#e5f6f2', caption: '自分のための時間' },
] as const;
export type Category = typeof CATEGORIES[number]['id'];
export type PlanEvent = {id:string; title:string; category:Category; start:string; end:string; allDay:boolean; location:string; note:string; updatedAt:string};
export const pad=(n:number)=>String(n).padStart(2,'0');
export const dateKey=(d:Date)=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
export const dateOf=(s:string)=>new Date(s.slice(0,10)+'T12:00:00');
export const nextDate=(s:string,n=1)=>{const d=dateOf(s);d.setDate(d.getDate()+n);return dateKey(d)};
export const dayLabel=(s:string)=>dateOf(s).toLocaleDateString('ja-JP',{month:'long',day:'numeric',weekday:'short'});
export function validDate(s:unknown):s is string {if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=dateOf(s);return !Number.isNaN(+d)&&dateKey(d)===s&&s>='1900-01-01'&&s<='2200-12-31'}
export function validDateTime(s:unknown):s is string {return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}T([01]\d|2[0-3]):[0-5]\d$/.test(s)&&validDate(s.slice(0,10))}
export function validateEvent(e:unknown):PlanEvent {const v=e as PlanEvent;if(!v||typeof v!=='object'||typeof v.id!=='string'||v.id.length>100||!v.id||typeof v.title!=='string'||!v.title.trim()||v.title.length>100||!CATEGORIES.some(c=>c.id===v.category)||!validDateTime(v.start)||!validDateTime(v.end)||v.end<=v.start||typeof v.allDay!=='boolean'||typeof v.location!=='string'||v.location.length>200||typeof v.note!=='string'||v.note.length>2000)throw new Error('予定の形式を確認してください。');return {id:v.id,title:v.title.trim(),category:v.category,start:v.start,end:v.end,allDay:v.allDay,location:v.location,note:v.note,updatedAt:typeof v.updatedAt==='string'?v.updatedAt:new Date().toISOString()}}
export const onDay=(e:PlanEvent,day:string)=>e.start<nextDate(day)+'T00:00'&&e.end>day+'T00:00';
export const overlap=(a:PlanEvent,b:PlanEvent)=>a.id!==b.id&&!a.allDay&&!b.allDay&&a.start<b.end&&b.start<a.end;
export function collisionIds(events:PlanEvent[]){const ids=new Set<string>();for(let i=0;i<events.length;i++)for(let j=i+1;j<events.length;j++)if(overlap(events[i],events[j])){ids.add(events[i].id);ids.add(events[j].id)}return ids}
export function sampleEvents(today:string):PlanEvent[]{const base=dateOf(today);const d=(offset:number)=>{const x=new Date(base);x.setDate(x.getDate()+offset);return dateKey(x)};return [
['朝のウォーキング','self',0,'07:00','07:40','いつもの公園'],['チームミーティング','work',0,'10:00','11:00','オンライン'],['企画書を仕上げる','work',0,'14:00','15:30','オフィス'],['家族と夕ごはん','family',0,'18:30','20:00','自宅'],['お客様との打ち合わせ','side',1,'13:00','14:00','オンライン'],['学校の面談','family',1,'13:30','14:30','学校'],['読書の時間','self',3,'09:00','10:00',''],['週次レビュー','work',4,'16:00','17:00',''],['友人とランチ','self',6,'12:00','13:30','駅前のカフェ'],['制作作業','side',7,'10:00','12:00',''],['家族でお出かけ','family',9,'09:00','17:00',''],['来月の予定を整理','self',12,'20:00','20:30',''],['資料のチェック','work',-2,'11:00','12:00',''],['買い出し','family',-4,'16:00','17:00','']
].map((v,i)=>({id:'sample-'+i,title:String(v[0]),category:v[1] as Category,start:d(Number(v[2]))+'T'+v[3],end:d(Number(v[2]))+'T'+v[4],allDay:false,location:String(v[5]),note:'サンプルの予定です。',updatedAt:new Date().toISOString()}))}
