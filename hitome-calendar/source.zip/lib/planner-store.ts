import {type PlanEvent,validateEvent} from './planner';
const DB_NAME='hitome-planner-v1';
let cached:Promise<IDBDatabase>|null=null;
function open(){if(!cached)cached=new Promise<IDBDatabase>((resolve,reject)=>{if(!window.indexedDB){reject(new Error('このブラウザでは保存機能を利用できません。'));return;}const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>r.result.createObjectStore('events',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onblocked=()=>reject(new Error('他のタブを閉じて開き直してください。'));}).catch(e=>{cached=null;throw e});return cached}
export async function allEvents(){const db=await open();return new Promise<PlanEvent[]>((resolve,reject)=>{const r=db.transaction('events').objectStore('events').getAll();r.onsuccess=()=>{try{resolve(r.result.map(validateEvent))}catch(e){reject(e)}};r.onerror=()=>reject(r.error)})}
async function write(run:(s:IDBObjectStore)=>void){const db=await open();return new Promise<void>((resolve,reject)=>{const t=db.transaction('events','readwrite');t.oncomplete=()=>resolve();t.onabort=t.onerror=()=>reject(t.error||new Error('保存できませんでした。'));try{run(t.objectStore('events'))}catch(e){t.abort();reject(e)}})}
export const saveEvent=(event:PlanEvent)=>write(s=>s.put(validateEvent(event)));
export const deleteEvent=(id:string)=>write(s=>s.delete(id));
export const mergeEvents=(events:PlanEvent[])=>{const safe=events.map(validateEvent);return write(s=>{for(const e of safe)s.put(e)})};
export function readBackup(data:unknown):PlanEvent[]{const v=data as {app?:string;version?:number;events?:unknown[]};if(!v||v.app!=='hitome-planner'||v.version!==1||!Array.isArray(v.events)||v.events.length>5000)throw new Error('ひとめ予定帳のバックアップを選んでください。');const items=v.events.map(validateEvent);if(new Set(items.map(e=>e.id)).size!==items.length)throw new Error('重複した予定IDがあります。');return items}
