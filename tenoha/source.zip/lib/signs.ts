export type SignId='thanks'|'please'|'morning'|'hello'|'sorry'|'understand'|'congrats'|'energy';
export type Sign={id:SignId;label:string;reading:string;category:string;seconds:number;steps:string[];source:string;aliases:string[]};
const osaki='https://www.city.osaki.miyagi.jp/shisei/soshikikarasagasu/minseibu/koreikaigoka/3_1/17096.html';
const kushiro='https://www.city.kushiro.lg.jp/kenfuku/fukushi/1004747/1004748/1009905/1007918/1007932.html';
export const signs:Sign[]=[
{id:'thanks',label:'ありがとう',reading:'ARIGATOU',category:'気持ち',seconds:4.8,steps:['左手の甲に、右手の小指側を添えます。','右手を上へ動かします。','軽く頭を下げます。'],source:osaki,aliases:['ありがとうございます','感謝しています','助かりました','どうもありがとう','感謝を伝えたい','手伝ってくれてありがとう','お礼を言いたい','感謝','お礼']},
{id:'please',label:'よろしくお願いします',reading:'YOROSHIKU',category:'あいさつ',seconds:5.8,steps:['右手のこぶしを、鼻の前に置きます。','右手を開き、前へ動かします。','頭を軽く下げます。'],source:osaki,aliases:['よろしく','よろしくお願い','お願いします','お願いしたいです','初対面のあいさつ','これからよろしく','お願い','よろしくね']},
{id:'morning',label:'おはよう',reading:'OHAYOU',category:'あいさつ',seconds:6.4,steps:['右手のこぶしを、こめかみの横に置きます。','こぶしを下に動かします。','両手の人差し指を向かい合わせ、曲げます。'],source:kushiro,aliases:['おはようございます','朝のあいさつ','おはようさん','朝起きたとき','朝の挨拶','おはよ']},
{id:'hello',label:'こんにちは',reading:'KONNICHIWA',category:'あいさつ',seconds:6.4,steps:['右手の人差し指と中指を、額の前に置きます。','両手の人差し指を立て、向かい合わせます。','人差し指をおじぎするように曲げます。'],source:kushiro,aliases:['こんにちわ','昼のあいさつ','日中のあいさつ','こんにちはです','昼の挨拶','昼に会ったとき']},
{id:'sorry',label:'すみません',reading:'SUMIMASEN',category:'気持ち',seconds:5.6,steps:['右手の親指と人差し指を、眉間に寄せます。','右手の指をそろえて開きます。','手を前下方へ動かし、軽く頭を下げます。'],source:osaki,aliases:['ごめんなさい','ごめんね','申し訳ありません','謝りたい','謝罪したい','すみませんでした','すいません','ごめん','失礼しました']},
{id:'understand',label:'わかる',reading:'WAKARU',category:'気持ち',seconds:4.6,steps:['開いた右手を、胸の前に置きます。','手のひらを体に向けます。','胸に沿って、右手を下に動かします。'],source:osaki,aliases:['わかりました','理解しました','わかった','分かる','分かりました','理解できました','意味がわかる','理解','了解しました']},
{id:'congrats',label:'おめでとう',reading:'OMEDETOU',category:'気持ち',seconds:4.8,steps:['両手を軽く握り、おなかの前に置きます。','両手を上へ動かします。','指を開きます。'],source:osaki,aliases:['おめでとうございます','お祝いしたい','誕生日おめでとう','合格おめでとう','祝福を伝えたい','お祝い','祝福','お誕生日おめでとう']},
{id:'energy',label:'元気',reading:'GENKI',category:'気持ち',seconds:4.8,steps:['両ひじを外に開き、こぶしを胸の前に置きます。','両方のこぶしを下へ動かします。','もう一度、下へ動かします。'],source:'https://www.city.urayasu.lg.jp/_res/projects/default_project/_page_/001/026/701/panfret.pdf',aliases:['元気です','元気だよ','がんばる','頑張る','頑張ります','元気いっぱい','がんばります','元気にしています']}
];
// A small, on-device multinomial Naive Bayes model. No remote inference or translation.
const normalize=(s:string)=>s.normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
function features(s:string){const out:string[]=[];for(let n=2;n<=3;n++)for(let i=0;i<=s.length-n;i++)out.push(s.slice(i,i+n));return out;}
const vocabulary=new Set<string>();
const classes=signs.map(sign=>{const counts=new Map<string,number>();let total=0;for(const text of [sign.label,...sign.aliases])for(const f of features(normalize(text))){counts.set(f,(counts.get(f)||0)+1);total++;vocabulary.add(f);}return{sign,counts,total};});
export function suggest(text:string):Sign[]{const norm=normalize(text);if(norm.length<2)return[];const exact=signs.find(s=>[s.label,...s.aliases].some(a=>normalize(a)===norm));if(exact)return[exact];const all=features(norm),known=all.filter(f=>vocabulary.has(f));if(!known.length||known.length/all.length<.35)return[];const scores=classes.map(c=>({sign:c.sign,score:known.reduce((acc,f)=>acc+Math.log(((c.counts.get(f)||0)+1)/(c.total+vocabulary.size)),0),hits:known.filter(f=>c.counts.has(f)).length/known.length})).sort((a,b)=>b.score-a.score);if(scores[0].hits<.5||scores[0].score-scores[1].score<.4)return[];return scores.filter((s,i)=>i<2&&s.hits>.5&&scores[0].score-s.score<2.5).map(s=>s.sign);}
