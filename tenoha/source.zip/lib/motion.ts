import * as THREE from 'three';
import type {SignId} from './signs';
type V=[number,number,number];
export type HandPose={p:V;dir:V;normal:V;curl:number[];spread:number};
export type Pose={right:HandPose;left:HandPose;bow:number};
const shapes:Record<string,number[]>={open:[0,0,0,0,.2],fist:[1,1,1,1,1],index:[0,1,1,1,.8],two:[0,0,1,1,.8],pinch:[.6,1,1,1,.6]};
const hand=(p:V,dir:V=[0,1,0],normal:V=[0,0,1],shape='open',spread=0):HandPose=>({p,dir,normal,curl:shapes[shape],spread});
const idle=():Pose=>({right:hand([-.47,.89,.09],[0,-1,.2],[.8,0,1]),left:hand([.47,.89,.09],[0,-1,.2],[-.8,0,1]),bow:0});
const handsBow=(bend=0):Pose=>({right:{...hand([-.2,1.16,.48],[0,1,0],[1,0,0],'index'),curl:[bend,1,1,1,.8]},left:{...hand([.2,1.16,.48],[0,1,0],[-1,0,0],'index'),curl:[bend,1,1,1,.8]},bow:bend*.14});
function frames(id:SignId):[number,Pose][]{const base=idle();const one=(right:HandPose,bow=0):Pose=>({...base,right,bow});let keys:[number,Pose][]=[];
if(id==='thanks'){const left=hand([.19,1.30,.42],[-1,0,0],[0,-1,0]);const start={right:hand([-.025,1.415,.34],[0,0,1],[1,0,0]),left,bow:0};keys=[[.23,start],[.42,start],[.72,{...start,right:hand([-.025,1.88,.34],[0,0,1],[1,0,0]),bow:.15}],[.84,{...start,right:hand([-.025,1.88,.34],[0,0,1],[1,0,0]),bow:.15}]];}
if(id==='please'){keys=[[.24,one(hand([-.03,1.83,.47],[0,1,0],[1,0,0],'fist'))],[.4,one(hand([-.03,1.83,.47],[0,1,0],[1,0,0],'fist'))],[.65,one(hand([-.08,1.38,.65],[0,1,0],[1,0,0]),.17)],[.83,one(hand([-.08,1.38,.65],[0,1,0],[1,0,0]),.17)]];}
if(id==='morning'||id==='hello'){const morning=id==='morning';keys=[[.17,one(hand(morning?[-.27,2.01,.08]:[-.12,1.88,.40],[0,1,0],[0,0,1],morning?'fist':'two'))],[.3,one(hand(morning?[-.27,1.5,.25]:[-.12,1.88,.40],[0,1,0],[0,0,1],morning?'fist':'two'))],[.51,handsBow()],[.66,handsBow(.7)],[.81,handsBow(.7)]];}
if(id==='sorry'){keys=[[.22,one(hand([-.07,1.90,.43],[0,1,0],[0,0,-1],'pinch'))],[.39,one(hand([-.07,1.90,.43],[0,1,0],[0,0,-1],'pinch'))],[.68,one(hand([-.07,1.36,.64],[0,1,0],[1,0,0]),.2)],[.83,one(hand([-.07,1.36,.64],[0,1,0],[1,0,0]),.2)]];}
if(id==='understand'){keys=[[.24,one(hand([-.03,1.35,.24],[0,1,0],[0,0,-1]))],[.40,one(hand([-.03,1.35,.24],[0,1,0],[0,0,-1]))],[.70,one(hand([-.03,1.07,.27],[0,1,0],[0,0,-1]))],[.83,one(hand([-.03,1.07,.27],[0,1,0],[0,0,-1]))]];}
if(id==='congrats'){const low={right:hand([-.23,1.01,.37],[0,1,0],[0,0,1],'fist'),left:hand([.23,1.01,.37],[0,1,0],[0,0,1],'fist'),bow:0};const high={right:hand([-.38,1.68,.4],[0,1,0],[0,0,1],'open',1),left:hand([.38,1.68,.4],[0,1,0],[0,0,1],'open',1),bow:0};keys=[[.23,low],[.36,low],[.72,high],[.83,high]];}
if(id==='energy'){const at=(y:number):Pose=>({right:hand([-.27,y,.4],[0,1,0],[1,0,0],'fist'),left:hand([.27,y,.4],[0,1,0],[-1,0,0],'fist'),bow:0});keys=[[.22,at(1.42)],[.37,at(1.2)],[.51,at(1.42)],[.67,at(1.2)],[.83,at(1.2)]];}
return[[0,base],...keys,[1,base]];}
export function orientation(h:HandPose){const y=new THREE.Vector3(...h.dir).normalize();const z=new THREE.Vector3(...h.normal);z.addScaledVector(y,-z.dot(y)).normalize();const x=new THREE.Vector3().crossVectors(y,z).normalize();z.crossVectors(x,y);return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,y,z));}
export function sampleMotion(id:SignId,t:number){const f=frames(id);const v=Math.min(1,Math.max(0,t));let i=0;while(i<f.length-2&&v>f[i+1][0])i++;const [a,A]=f[i],[b,B]=f[i+1];let k=(v-a)/(b-a);k=k*k*(3-2*k);const mix=(x:number,y:number)=>x+(y-x)*k;const hp=(p:HandPose,q:HandPose)=>({position:new THREE.Vector3(...p.p).lerp(new THREE.Vector3(...q.p),k),quaternion:orientation(p).slerp(orientation(q),k),curl:p.curl.map((x,j)=>mix(x,q.curl[j])),spread:mix(p.spread,q.spread)});return{right:hp(A.right,B.right),left:hp(A.left,B.left),bow:mix(A.bow,B.bow)};}
