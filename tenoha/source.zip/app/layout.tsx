import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'てのは｜手話アバタースタジオ',description:'伝えたい気持ちを選んで、3Dアバターの手の動きを見てみよう。8つの定型表現を収録した監修前の動作デモ。',icons:{icon:'/favicon.svg'},other:{'codex-preview':'development'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ja"><body>{children}</body></html>}
