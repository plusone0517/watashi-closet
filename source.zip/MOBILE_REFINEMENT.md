# Mobile refinement — 2026-10-01

Use 16px text in mobile search/quantity inputs for readable, consistent forms.

No application scripts or persisted-data formats changed.
