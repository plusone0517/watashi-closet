export const categories={top:'トップス',bottom:'ボトムス',dress:'ワンピース',outer:'羽織り',shoes:'シューズ',bag:'バッグ',accessory:'小物'} as const;
export type Category=keyof typeof categories;
export const scenes={daily:'普段着',work:'お仕事',outing:'お出かけ'} as const;
export type Scene=keyof typeof scenes;
export const seasons={light:'薄手・夏向け',mid:'春秋・中間',warm:'厚手・冬向け',all:'通年'} as const;
export type Season=keyof typeof seasons;
export const colors={ivory:['白・アイボリー','#eeece4'],black:['ブラック','#252525'],gray:['グレー','#8a8b8d'],navy:['ネイビー','#253751'],beige:['ベージュ','#c5af90'],brown:['ブラウン','#83583e'],blue:['ブルー','#6c91b7'],green:['グリーン','#658474'],red:['レッド','#ae5551'],pink:['ピンク','#dca2b0'],other:['その他','#bcaacf']} as const;
export type Color=keyof typeof colors;
export const genders={unspecified:'回答しない・未設定',female:'女性',male:'男性',other:'その他'} as const;
export const stylePreferences={auto:'おまかせ',simple:'シンプル',smart:'きれいめ',casual:'カジュアル',colorful:'色を楽しむ'} as const;
export const garmentLines={unisex:'こだわらない・共用',women:'レディース',men:'メンズ'} as const;
export const dressiness={auto:'未設定（場面から参考）',casual:'カジュアル',smart:'きれいめ',formal:'フォーマル'} as const;
export type Profile={age:string;gender:keyof typeof genders;style:keyof typeof stylePreferences};
export const defaultProfile:Profile={age:'',gender:'unspecified',style:'auto'};
export const destinations={none:'指定しない',cafe:'カフェ・友人とランチ',shopping:'買い物・街歩き',office:'仕事・商談',dinner:'レストラン・食事会',ceremony:'式典・お祝い',park:'公園・散歩',travel:'旅行・観光',school:'学校行事'} as const;
export type Destination=keyof typeof destinations;
export type GarmentLine=keyof typeof garmentLines;
export type Dressiness=keyof typeof dressiness;
export const destinationScene:Record<Destination,Scene>={none:'outing',cafe:'outing',shopping:'outing',office:'work',dinner:'outing',ceremony:'outing',park:'daily',travel:'outing',school:'outing'};
export type Item={id:string;name:string;category:Category;color:Color;season:Season;scenes:Scene[];rainOK:boolean;available:boolean;photo:string;note:string;createdAt:string;sampleCell?:number;line?:GarmentLine;dressiness?:Dressiness;walkable?:boolean};
export type Conditions={scene:Scene;weather:'sunny'|'cloudy'|'rain';temperature:number;destination?:Destination;destinationName?:string};
export type Saved={id:string;name:string;date:string;items:Item[];conditions:Conditions;createdAt:string;profile?:Profile};
export type Data={version:1;items:Item[];outfits:Saved[];profile?:Profile};
export const emptyData:Data={version:1,items:[],outfits:[]};
export const weatherLabels={sunny:'晴れ',cloudy:'くもり',rain:'雨'} as const;
export const demoItems:Item[]=[
 ['白のコットンシャツ','top','ivory','mid',['work','outing','daily'],false],
 ['ネイビーのニット','top','navy','warm',['work','outing','daily'],false],
 ['黒のベーシックTシャツ','top','black','light',['daily','outing'],false],
 ['ベージュのテーパードパンツ','bottom','beige','mid',['work','outing'],false],
 ['インディゴのデニム','bottom','blue','all',['daily','outing'],false],
 ['黒のミディスカート','bottom','black','all',['work','outing'],false],
 ['チャコールのジャケット','outer','gray','mid',['work','outing'],false],
 ['白のスニーカー','shoes','ivory','all',['daily','outing'],false],
 ['ブラウンのショルダーバッグ','bag','brown','all',['daily','work','outing'],false],
].map((v,i)=>({id:'demo-'+i,name:v[0],category:v[1],color:v[2],season:v[3],scenes:v[4],rainOK:v[5],available:true,photo:'',note:'体験用のサンプルアイテム',sampleCell:i,createdAt:'2026-09-30T00:00:00.000Z',line:i===5?'women':'unisex',dressiness:[0,3,5,6].includes(i)?'smart':'casual',walkable:i===7} as Item));
const neutral=new Set<Color>(['ivory','black','gray','navy','beige','brown']);
export function effectiveDressiness(item:Item){return item.dressiness&&item.dressiness!=='auto'?item.dressiness:item.scenes.includes('work')?'smart':'casual';}
export function destinationLabel(c:Conditions){return c.destinationName?.trim()||destinations[c.destination||'none'];}
function wantsSmart(c:Conditions){return ['office','dinner','ceremony','school'].includes(c.destination||'none');}
function wantsWalking(c:Conditions){return ['shopping','park','travel'].includes(c.destination||'none');}
export function suitability(item:Item,c:Conditions,profile:Profile=defaultProfile){
 let score=item.scenes.includes(c.scene)?8:0;
 const ranges={light:[20,40],mid:[12,25],warm:[-20,17],all:[-20,45]};const [lo,hi]=ranges[item.season];score+=c.temperature>=lo&&c.temperature<=hi?6:-Math.min(10,Math.min(Math.abs(c.temperature-lo),Math.abs(c.temperature-hi)));
 if(c.weather==='rain'&&item.rainOK)score+=5;
 const style=effectiveDressiness(item);
 if(wantsSmart(c))score+=style==='formal'?7:style==='smart'?6:-3;
 if(c.destination==='park')score+=style==='casual'?5:0;
 if(wantsWalking(c)&&item.category==='shoes')score+=item.walkable?10:0;
 if(profile.style==='smart')score+=style==='smart'||style==='formal'?4:0;
 if(profile.style==='casual')score+=style==='casual'?4:0;
 if(profile.style==='simple')score+=neutral.has(item.color)?4:0;
 if(profile.style==='colorful')score+=neutral.has(item.color)?0:5;
 // An explicitly chosen style overrides age and gender hints. No items are excluded.
 if(profile.style==='auto'){
  if(profile.age!==''&&Number(profile.age)>=50&&neutral.has(item.color))score+=1;
  if(profile.gender==='female'&&item.line==='women'||profile.gender==='male'&&item.line==='men')score+=2;
  if(profile.gender!=='unspecified'&&(!item.line||item.line==='unisex'))score+=1;
 }
 return score;
}
export function proposals(items:Item[],c:Conditions,profile:Profile=defaultProfile):Item[][]{
 const available=items.filter(i=>i.available);const get=(cat:Category)=>available.filter(i=>i.category===cat).sort((a,b)=>suitability(b,c,profile)-suitability(a,c,profile)).slice(0,14);
 const tops=get('top'),bottoms=get('bottom'),dresses=get('dress');let bases:Item[][]=[];for(const t of tops)for(const b of bottoms)bases.push([t,b]);for(const d of dresses)bases.push([d]);
 const score=(row:Item[])=>row.reduce((n,i)=>n+suitability(i,c,profile),0)/row.length+(row.length===2&&(neutral.has(row[0].color)||neutral.has(row[1].color)||row[0].color===row[1].color)?3:0);
 bases.sort((a,b)=>score(b)-score(a));const shoes=get('shoes'),bags=get('bag'),outers=get('outer'),accessories=get('accessory');
 const needsLayer=c.temperature<20||['office','ceremony'].includes(c.destination||'none');
 const variants:Item[][]=[];for(const [i,base] of bases.entries()){const row=[...base];if(needsLayer&&outers[0])row.push(outers[Math.min(i%2,outers.length-1)]);if(shoes[0])row.push(shoes[Math.min(i%2,shoes.length-1)]);if(bags[0])row.push(bags[Math.min(i%2,bags.length-1)]);if(accessories[0])row.push(accessories[Math.min(i%2,accessories.length-1)]);variants.push(row);}
 if(variants.length===1){for(const pool of [shoes,bags,outers,accessories])for(const item of pool.slice(1,4)){if(item.category==='outer'&&!needsLayer)continue;const base=variants[0];variants.push([...base.filter(i=>i.category!==item.category),item]);}}
 return variants;
}
export function personalNotes(items:Item[],c:Conditions,profile:Profile=defaultProfile){
 const n:string[]=[];
 if(c.destination&&c.destination!=='none'){
  if(wantsSmart(c))n.push(`${destinationLabel(c)}に合わせ、きれいめ・フォーマルとして登録した服を優先しています。`);
  else if(c.destination==='park')n.push('公園・散歩には、カジュアルな服を優先しています。');
  if(wantsWalking(c))n.push('歩く予定に合わせ、「歩きやすい」と登録したシューズを優先しています。');
  if(c.destination==='cafe')n.push('カフェ・ランチには、お出かけ向けとして登録した服を組み合わせています。');
 }
 if(profile.style!=='auto')n.push(`好みの「${stylePreferences[profile.style]}」を年齢・性別の参考条件より優先しています。`);
 else{
  if(profile.age!==''&&Number(profile.age)>=50)n.push(`${profile.age}歳の参考条件として、白・黒・ネイビーなどの落ち着いた色を少し優先。色を楽しみたい日は「好み」を変更できます。`);
  else if(profile.age!=='')n.push(`${profile.age}歳で登録されています。年齢で服を制限せず、今日の予定を優先しています。`);
  if(profile.gender==='female'||profile.gender==='male')n.push(`${profile.gender==='female'?'レディース':'メンズ'}として登録した服と、共用の服を少し優先しています。ほかのタイプも候補に残します。`);
 }
 return n;
}
export function outfitNotes(items:Item[],c:Conditions){const n:string[]=[];
 if(items.some(i=>!i.scenes.includes(c.scene)))n.push('この場面向けの服が少ないため、ほかの場面の服も含めています。');
 if(c.temperature<15&&!items.some(i=>i.category==='outer'))n.push('羽織りが未登録です。寒さに合わせて、上着の追加を検討してください。');
 if(c.weather==='rain'&&!items.some(i=>i.category==='shoes'&&i.rainOK))n.push('雨向けのシューズが未登録です。足元と傘を確認しましょう。');
 if(items.some(i=>suitability(i,c)<5))n.push('気温・場面の目安に合わない服を含みます。実際の厚みと体感で調整してください。');
 if(wantsWalking(c)&&!items.some(i=>i.category==='shoes'&&i.walkable))n.push('歩きやすいシューズの登録がありません。靴の情報で「歩きやすい」を設定できます。');
 if(wantsSmart(c)&&items.some(i=>['top','bottom','dress'].includes(i.category)&&effectiveDressiness(i)==='casual'))n.push('カジュアルな服が含まれています。外出先の服装ルールも確認してください。');
 if(c.destination==='ceremony')n.push('式典ごとのドレスコードや格式への適合は自動判定していません。案内状などで確認してください。');
 if(c.temperature>=25&&items.some(i=>i.category==='outer')&&['office','ceremony'].includes(c.destination||''))n.push('羽織りは室内や到着時の候補です。暑い屋外では体感に合わせて脱いで調整してください。');
 return n;
}
export function validateProfile(raw:unknown):Profile{if(raw===undefined)return {...defaultProfile};const p=raw as Profile;if(!p||typeof p.age!=='string'||!(p.age===''||/^\d{1,3}$/.test(p.age)&&Number(p.age)<=120)||!Object.hasOwn(genders,p.gender)||!Object.hasOwn(stylePreferences,p.style))throw Error('プロフィールの形式を確認してください。');return {age:p.age,gender:p.gender,style:p.style};}
export function normalizeConditions(c:Conditions):Conditions{if(c.destination!==undefined&&!Object.hasOwn(destinations,c.destination)||c.destinationName!==undefined&&(typeof c.destinationName!=='string'||c.destinationName.length>80))throw Error('外出先の形式を確認してください。');return {scene:c.scene,weather:c.weather,temperature:c.temperature,destination:c.destination||'none',destinationName:c.destinationName||''};}
export function localDay(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function isStr(v:unknown,max:number){return typeof v==='string'&&v.length<=max;}
export function validateBackup(raw:unknown):Data{
 const x=raw as Data;if(!x||x.version!==1||!Array.isArray(x.items)||!Array.isArray(x.outfits)||x.items.length>1000||x.outfits.length>1000)throw Error('このアプリのバックアップファイルを選んでください。');
 const item=(i:Item):Item=>{if(i.line!==undefined&&!Object.hasOwn(garmentLines,i.line)||i.dressiness!==undefined&&!Object.hasOwn(dressiness,i.dressiness)||i.walkable!==undefined&&typeof i.walkable!=='boolean')throw Error('服の追加情報が正しくありません。');if(!i||!isStr(i.id,100)||!i.id||!isStr(i.name,60)||!i.name.trim()||!Object.hasOwn(categories,i.category)||!Object.hasOwn(colors,i.color)||!Object.hasOwn(seasons,i.season)||!Array.isArray(i.scenes)||!i.scenes.length||!i.scenes.every(s=>Object.hasOwn(scenes,s))||typeof i.available!=='boolean'||typeof i.rainOK!=='boolean'||!isStr(i.photo,1800000)||(i.photo&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(i.photo))||!isStr(i.note,300)||!isStr(i.createdAt,40))throw Error('バックアップの服データが正しくありません。');return {id:i.id,name:i.name,category:i.category,color:i.color,season:i.season,scenes:[...i.scenes],available:i.available,rainOK:i.rainOK,photo:i.photo,note:i.note,createdAt:i.createdAt,line:i.line||'unisex',dressiness:i.dressiness||'auto',walkable:i.walkable||false};};
 const items=x.items.map(item);if(new Set(items.map(i=>i.id)).size!==items.length)throw Error('服のIDが重複しています。');
 const outfits=x.outfits.map(o=>{if(!o||!isStr(o.id,100)||!o.id||!isStr(o.name,80)||!isStr(o.date,10)||!/^\d{4}-\d{2}-\d{2}$/.test(o.date)||!Array.isArray(o.items)||o.items.length>10||!o.conditions||!Object.hasOwn(scenes,o.conditions.scene)||!Object.hasOwn(weatherLabels,o.conditions.weather)||!Number.isFinite(o.conditions.temperature)||o.conditions.temperature< -20||o.conditions.temperature>45||!isStr(o.createdAt,40))throw Error('バックアップのコーデデータが正しくありません。');return{id:o.id,name:o.name,date:o.date,items:o.items.map(item),conditions:normalizeConditions(o.conditions),createdAt:o.createdAt,profile:validateProfile(o.profile)};});
 return {version:1,items,outfits,profile:validateProfile(x.profile)};
}
