export const categories={top:'トップス',bottom:'ボトムス',dress:'ワンピース',outer:'羽織り',shoes:'シューズ',bag:'バッグ',accessory:'小物'} as const;
export type Category=keyof typeof categories;
export const scenes={daily:'普段着',work:'お仕事',outing:'お出かけ'} as const;
export type Scene=keyof typeof scenes;
export const seasons={light:'薄手・夏向け',mid:'春秋・中間',warm:'厚手・冬向け',all:'通年'} as const;
export type Season=keyof typeof seasons;
export const colors={ivory:['白・アイボリー','#eeece4'],black:['ブラック','#252525'],gray:['グレー','#8a8b8d'],navy:['ネイビー','#253751'],beige:['ベージュ','#c5af90'],brown:['ブラウン','#83583e'],blue:['ブルー','#6c91b7'],green:['グリーン','#658474'],red:['レッド','#ae5551'],pink:['ピンク','#dca2b0'],other:['その他','#bcaacf']} as const;
export type Color=keyof typeof colors;
export type Item={id:string;name:string;category:Category;color:Color;season:Season;scenes:Scene[];rainOK:boolean;available:boolean;photo:string;note:string;createdAt:string;sampleCell?:number};
export type Conditions={scene:Scene;weather:'sunny'|'cloudy'|'rain';temperature:number};
export type Saved={id:string;name:string;date:string;items:Item[];conditions:Conditions;createdAt:string};
export type Data={version:1;items:Item[];outfits:Saved[]};
export const emptyData:Data={version:1,items:[],outfits:[]};
export const weatherLabels={sunny:'晴れ',cloudy:'くもり',rain:'雨'} as const;
export const demoItems:Item[]=[
 ['白のコットンシャツ','top','ivory','mid',['work','outing','daily'],false],
 ['ネイビーのニット','top','navy','warm',['work','outing','daily'],false],
 ['黒のベーシックTシャツ','top','black','light',['daily','outing'],false],
 ['ベージュのテーパードパンツ','bottom','beige','mid',['work','outing'],false],
 ['インディゴのデニム','bottom','blue','all',['daily','outing'],false],
 ['黒のミディスカート','bottom','black','all',['work','outing'],false],
 ['チャコールのジャケット','outer','gray','mid',['work','outing'],false],
 ['白のスニーカー','shoes','ivory','all',['daily','outing'],false],
 ['ブラウンのショルダーバッグ','bag','brown','all',['daily','work','outing'],false],
].map((v,i)=>({id:'demo-'+i,name:v[0],category:v[1],color:v[2],season:v[3],scenes:v[4],rainOK:v[5],available:true,photo:'',note:'体験用のサンプルアイテム',sampleCell:i,createdAt:'2026-09-30T00:00:00.000Z'} as Item));
const neutral=new Set<Color>(['ivory','black','gray','navy','beige','brown']);
export function suitability(item:Item,c:Conditions){let score=item.scenes.includes(c.scene)?8:0;const ranges={light:[20,40],mid:[12,25],warm:[-20,17],all:[-20,45]};const [lo,hi]=ranges[item.season];score+=c.temperature>=lo&&c.temperature<=hi?6:-Math.min(10,Math.min(Math.abs(c.temperature-lo),Math.abs(c.temperature-hi)));if(c.weather==='rain'&&item.rainOK)score+=5;return score;}
export function proposals(items:Item[],c:Conditions):Item[][]{
 const available=items.filter(i=>i.available);const get=(cat:Category)=>available.filter(i=>i.category===cat).sort((a,b)=>suitability(b,c)-suitability(a,c)).slice(0,14);
 const tops=get('top'),bottoms=get('bottom'),dresses=get('dress');let bases:Item[][]=[];for(const t of tops)for(const b of bottoms)bases.push([t,b]);for(const d of dresses)bases.push([d]);
 const score=(row:Item[])=>row.reduce((n,i)=>n+suitability(i,c),0)/row.length+(row.length===2&&(neutral.has(row[0].color)||neutral.has(row[1].color)||row[0].color===row[1].color)?3:0);
 bases.sort((a,b)=>score(b)-score(a));const shoes=get('shoes'),bags=get('bag'),outers=get('outer'),accessories=get('accessory');
 const variants:Item[][]=[];for(const [i,base] of bases.entries()){const row=[...base];if(c.temperature<20&&outers[0])row.push(outers[Math.min(i%2,outers.length-1)]);if(shoes[0])row.push(shoes[Math.min(i%2,shoes.length-1)]);if(bags[0])row.push(bags[Math.min(i%2,bags.length-1)]);if(accessories[0])row.push(accessories[Math.min(i%2,accessories.length-1)]);variants.push(row);}
 // With one base, offer alternatives from optional slots too.
 if(variants.length===1){for(const pool of [shoes,bags,outers,accessories])for(const item of pool.slice(1,4)){if(item.category==='outer'&&c.temperature>=20)continue;const base=variants[0];variants.push([...base.filter(i=>i.category!==item.category),item]);}}
 return variants;
}
export function outfitNotes(items:Item[],c:Conditions){const n:string[]=[];if(items.some(i=>!i.scenes.includes(c.scene)))n.push('この場面向けの服が少ないため、ほかの場面の服も含めています。');if(c.temperature<15&&!items.some(i=>i.category==='outer'))n.push('羽織りが未登録です。寒さに合わせて、上着の追加を検討してください。');if(c.weather==='rain'&&!items.some(i=>i.category==='shoes'&&i.rainOK))n.push('雨向けのシューズが未登録です。足元と傘を確認しましょう。');if(items.some(i=>suitability(i,c)<5))n.push('気温の目安に合わない服を含みます。実際の厚みと体感で調整してください。');return n;}
export function localDay(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function isStr(v:unknown,max:number){return typeof v==='string'&&v.length<=max;}
export function validateBackup(raw:unknown):Data{
 const x=raw as Data;if(!x||x.version!==1||!Array.isArray(x.items)||!Array.isArray(x.outfits)||x.items.length>1000||x.outfits.length>1000)throw Error('このアプリのバックアップファイルを選んでください。');
 const item=(i:Item):Item=>{if(!i||!isStr(i.id,100)||!i.id||!isStr(i.name,60)||!i.name.trim()||!Object.hasOwn(categories,i.category)||!Object.hasOwn(colors,i.color)||!Object.hasOwn(seasons,i.season)||!Array.isArray(i.scenes)||!i.scenes.length||!i.scenes.every(s=>Object.hasOwn(scenes,s))||typeof i.available!=='boolean'||typeof i.rainOK!=='boolean'||!isStr(i.photo,1800000)||(i.photo&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(i.photo))||!isStr(i.note,300)||!isStr(i.createdAt,40))throw Error('バックアップの服データが正しくありません。');return {id:i.id,name:i.name,category:i.category,color:i.color,season:i.season,scenes:[...i.scenes],available:i.available,rainOK:i.rainOK,photo:i.photo,note:i.note,createdAt:i.createdAt};};
 const items=x.items.map(item);if(new Set(items.map(i=>i.id)).size!==items.length)throw Error('服のIDが重複しています。');
 const outfits=x.outfits.map(o=>{if(!o||!isStr(o.id,100)||!o.id||!isStr(o.name,80)||!isStr(o.date,10)||!/^\d{4}-\d{2}-\d{2}$/.test(o.date)||!Array.isArray(o.items)||o.items.length>10||!o.conditions||!Object.hasOwn(scenes,o.conditions.scene)||!Object.hasOwn(weatherLabels,o.conditions.weather)||!Number.isFinite(o.conditions.temperature)||o.conditions.temperature< -20||o.conditions.temperature>45||!isStr(o.createdAt,40))throw Error('バックアップのコーデデータが正しくありません。');return{id:o.id,name:o.name,date:o.date,items:o.items.map(item),conditions:{...o.conditions},createdAt:o.createdAt};});
 return {version:1,items,outfits};
}
