export function openCamera(options?:{title?:string;facing?:'environment'|'user'}):Promise<File|null>;
