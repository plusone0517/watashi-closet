import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "わたしのクローゼット｜CLOSET",
  description: "手持ちの服を写真で管理。天気・気温・場面に合わせて組合せを作り、お気に入りのコーデを保存。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}
