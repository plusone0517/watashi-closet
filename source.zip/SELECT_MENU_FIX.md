# Select menu visibility — 2026-10-02

The standalone bundle did not generate bg-popover/text-popover-foreground utilities. Add explicit data-slot styles for the shared portalled select component: solid white surface, dark text, selected and focused states, 44px item targets, and a viewport width limit.

Applied to all SelectField menus including occasion, destination, profile, category and season. No application scripts or storage formats changed.
