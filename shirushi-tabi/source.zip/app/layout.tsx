import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "しるし旅｜御朱印・御城印の旅手帳",
  description: "訪問先と印の写真を、自分だけのアルバムと地図に残す旅手帳。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}
