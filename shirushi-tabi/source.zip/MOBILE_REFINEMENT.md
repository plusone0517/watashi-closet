# Mobile refinement — 2026-10-01

Fix narrow dialog grid tracks, stack date/prefecture fields at 400px, and constrain form controls without hiding overflowing content.

No application scripts or persisted-data formats changed.
